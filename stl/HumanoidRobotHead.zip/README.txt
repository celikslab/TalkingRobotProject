                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1037311
Animated Humanoid Robot Head by hyperplanemike is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

### Animated Humanoid Robot Head

This robot head features a movable mouth, eyes that move horizontally and vertically, and a pan/tilt neck. 

Completely wireless!

Video:
https://www.youtube.com/watch?v=Uj1b2VVOuDw&feature=share

Build instructions, electronics, and Arduino code:
https://hyperplaneinteractive.com/TCS/AnimatedHumanoidRobotHead


### Check out some of our other models:

[![Desktop Satellite Antenna](https://assets.pinshape.com/uploads/print_image/file/16623/pin_DSCN6381.JPG "Desktop Satellite Antenna") - Desktop Satellite Antenna](https://pinshape.com/items/27103-3d-printed-desktop-satellite-antenna)


[![Wind Energy Stored In Gravity](http://thingiverse-production-new.s3.amazonaws.com/renders/d1/92/43/1c/48/DSCN2013_preview_tinycard.JPG "Wind Energy Stored In Gravity") - Wind Energy Stored In Gravity](http://www.thingiverse.com/thing:952564)

[![Mini Vertical Wind Turbine](http://thingiverse-production-new.s3.amazonaws.com/renders/40/f2/ea/95/56/DSCN2085_preview_tinycard.JPG "Mini Vertical Wind Turbine") - Mini Vertical Wind Turbine](http://www.thingiverse.com/thing:971564)

[![Mike's Spool Holder](http://thingiverse-production-new.s3.amazonaws.com/renders/85/b6/72/73/7a/DSCN3020_preview_tinycard.JPG "Mike's Spool Holder") - Mike's Spool Holder](http://www.thingiverse.com/thing:1085724)

[![The Catfish - A fully working submarine](http://thingiverse-production-new.s3.amazonaws.com/renders/22/3c/c9/34/a4/DSCN1912_preview_tinycard.JPG "The Catfish - A fully working submarine") - The Catfish - A fully working submarine](http://www.thingiverse.com/thing:920376)

[![Pumpkin Carving Tools](http://thingiverse-production-new.s3.amazonaws.com/renders/98/37/97/98/56/1019152100d_preview_tinycard.jpg "Pumpkin Carving Tools") - Pumpkin Carving Tools](http://www.thingiverse.com/thing:1081121)